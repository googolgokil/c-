#include<iostream>
using namespace std;
int main()
{
    int a,b;
    int temp;
    a=10;
    b=20;
    temp=a;
    a=b;
    b=temp;
    cout<<a<<b;

    return 0;

}