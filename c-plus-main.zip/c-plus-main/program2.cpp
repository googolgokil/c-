#include<iostream>
using namespace std;
int main()
{
    int a;
    cout<<" Enter the Number";
    cin>>a;
    cout<<"Your Entered Number is : "<<a;
    return 0;
}