#include<iostream>
using namespace std;
int main()
{
   float annualSalary;
   cout<<"please Enter the annual Salary";
   cin>>annualSalary;
   float monthly = annualSalary/12;
   cout<<"your monthly salary is "<< monthly <<endl;
 
 

system("pause>0");
}
