#include<iostream>
using namespace std;
int main()
{
    int num, sum=0;
    cout<<"Enter the postive Number";
    cin>>num;
 
 for(int i=1; i<=num;i++)
 {
     sum= sum+i;
    
 }
 cout<<"Sum of the value is"<<sum;
}