#include<iostream>
using namespace std;
#include<string>
int main()
{ 
    int i;
   int marks[6]={19,10,8,17,9};
               // 0  1  2 3 4
   marks[3]=9;
   cout<< marks[3];
   cin>>marks[i-1];
   cout<<marks;
}
                




