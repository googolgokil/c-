#include<iostream>
using namespace std;
int main()
{
  int num int i=1;
  cout<<"Enter the postive NUmber";
  cin>>num;
  while(num>=i)
  {
    cout<<i<<endl;
     i++;
  }
}