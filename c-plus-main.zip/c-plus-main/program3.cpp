#include<iostream>
using namespace std;
int main()
{
    int a;
    int b,sum=0;
    cout<<"********************************\n";
    cout<<"Addition Value is Number";
    cin>>a>>b;
    sum=a+b;
    cout<<"your entered value is "<<sum;
    
}