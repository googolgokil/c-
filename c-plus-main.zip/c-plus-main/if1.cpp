#include<iostream>
using namespace std;
int main(){
    int a;
    cin>>a;
  if(a==0){
    cout<<a;
  }
  else if (a==1)
  {
    cout<<a;
  }
  else if(a==2){
    cout<<a;
  }
  else if(a==3)
  {
     cout<<a;
  }

  else 
  {
    cout<<"not vaild";
  }
return 0;
}