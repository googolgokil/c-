#include<iostream>
using namespace std;
int main()
{
  char c1,c2,c3,c4;
  cout<<"Enter the 4 letter";
  cin>>c1>>c2>>c3>>c4;
  cout<< int(c1)<< " " <<int(c2)<< " " <<int(c3)<< " " <<int(c4)<<endl;
  return 0;
}