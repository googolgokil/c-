#include<iostream>
using namespace std;
int main()
{
    int a,b;
    int remainder,quient;
    cout<<"Dividend";
    cin>>a;
    cout<<"Divisor";
    cin>>b;
   
quient= a/b;
remainder=a%b;
cout<< "Top value"<<quient;
cout<<"Remainder"<<remainder;

}