#include<iostream>
using namespace std;
int main()
{ 
  int i;
  cout<<"Enter";
  cin>>i;
  while(i==1)
  {
    cout<<i<<endl;
    

  }
    
    }
