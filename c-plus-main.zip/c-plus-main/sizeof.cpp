#include<iostream>
using namespace std;
int main()
{
int a=10;
int b=20;

int temp;
temp =a;
a=b;
b=temp;
/*
int temp;
  a=temp;
  b=a;
  temp=b;
 */
 cout<<a<<endl;
 cout<<b<<endl;
return 0;

}
