#include<iostream>
using namespace std;
int main()
{
    int host,guset;
    cout<<"hostUser";
    cin>>host ;
    system("cls");
    cout<<"gusetuser";
    cin>>guset;
    if(host==guset)
    {
        cout<<"Correct!";
    }
    else{
        cout<<"Failed";
    }
}