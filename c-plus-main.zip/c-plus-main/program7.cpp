#include<iostream>
using namespace std;
int main()
{
    int a ='A';
    cout<<a<< char (a);

}