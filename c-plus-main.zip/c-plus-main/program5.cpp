#include<iostream>
using namespace std;
int main()
{
cout<<"size of Int is ="<<sizeof(int)<<endl;
    cout<<"size of bool is ="<<sizeof(bool)<<endl;
      cout<<"size of Float is ="<<sizeof(float)<<endl;
        cout<<"size of Double is ="<<sizeof(double)<<endl;


}